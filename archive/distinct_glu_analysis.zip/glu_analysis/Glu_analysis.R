setwd("../glu_analysis/")
tmp<-read.csv("glu.txt", header = T, sep = "\t", row.names = NULL)
tmp
a<-as.tibble(tmp)
tmp<-filter(!is.na(tmp$Glu1))
dim(a)
tmp
a
#a$patient<-as.character(a$patient)
mdata <- melt(tmp, id=c("patient"))
mdata
dim(mdata)
mdata<-filter(mdata,!is.na(value))
mdata <-distinct(select(data.frame(a),c(patient, variable,value)))
mdata


favstats(mdata)

gf_histogram(~ Glu1,  data =a , binwidth = 5, center = 2.5)+
  ggtitle(label = "Histogram of Glucose Timepoint 1")+
  ggsave(filename = "Glu1_hist.png", width = 4,height = 4, units = "in", dpi = 300)

gf_histogram(~ Glu2,  data =a , binwidth = 5, center = 2.5)+
  ggtitle(label = "Histogram of Glucose Timepoint 2")+
  ggsave(filename = "Glu2_hist.png", width = 4,height = 4, units = "in", dpi = 300) 
  
gf_histogram(~ Glu3,  data =a , binwidth = 5, center = 2.5)+
  ggtitle(label = "Histogram of Glucose Timepoint 3")+
  ggsave(filename = "Glu3_hist.png", width = 4,height = 4, units = "in", dpi = 300)

gf_histogram(~ Glu4,  data =a , binwidth = 5, center = 2.5)+
  ggtitle(label = "Histogram of Glucose Timepoint 4")+
  ggsave(filename = "Glu4_hist.png", width = 4,height = 4, units = "in", dpi = 300) 
  
  gf_histogram(~ Glu5,  data =a , binwidth = 5, center = 2.5)+
  ggtitle(label = "Histogram of Glucose Timepoint 5")+
  ggsave(filename = "Glu5_hist.png", width = 4,height = 4, units = "in", dpi = 300)


mdata <-a %>% group_by(patient) %>%
    filter(!is.na(Glu1))
mdata <- melt(mdata, id=c("patient"))

mdata<-distinct(select(data.frame(mdata),c(patient,variable, value)))
mdata  
# 
# mdata$value
ggplot(data = mdata, mapping = aes(x = variable, y = value, group=patient)) +
  # geom_violin(mapping = aes(x = variable, y = value), alpha=1/4)+
  geom_point(width = 0.1, height = 0.1,mapping = aes(x = variable, y = value, color=variable, fill=NULL)) +
  geom_smooth(mapping = aes(color=variable),method = lm,se = FALSE, show.legend = F) +
  facet_wrap(nrow = 6, ncol = 8, facets = ~ patient) +
  theme(axis.text.x = element_text(angle = 90)) +
  ggtitle(label = "Newborn Glucose levels over Time") +
  theme_minimal()

###VIOLIN####
ggplot(data = mdata, mapping = aes(x = variable, y = value)) +
  geom_violin(mapping = aes(x = variable, y = value), alpha=1/4)+
  geom_jitter(width = 0.1, height = 0.1,mapping = aes(x = variable, y = value, color=variable, fill=NULL)) +
  #geom_smooth(mapping = aes(color=variable),method = lm,se = FALSE, show.legend = F) +
  #facet_wrap(nrow = 6, ncol = 8, facets = ~ patient) +
  theme(axis.text.x = element_text(angle = 90)) +
  ggtitle(label = "Newborn Glucose levels over Time") +
  theme_minimal()
#
tmp2<-read.csv("../H1bAC_analysis/h1b.txt", header = T, sep = "\t", row.names = NULL)
a2<-as.tibble(tmp2)
#a$patient<-as.character(a$patient)
mdata2 <- melt(a2, id=c("patient"))
mdata2<-filter(mdata2,!is.na(value))
mdata2<-distinct(select(data.frame(mdata2),c(patient,variable, value)))

class(mdata2)
mdata3<-merge.data.frame(mdata, mdata2, by = "patient")

mdata_glu1<-filter(mdata3,variable.x!="Glu5")
mdata_glu1
mdata_glu1<-filter(mdata_glu1,variable.y=="First.Trimester")
mdata_glu1<- unique.data.frame(x = mdata_glu1)
colnames(mdata_glu1)<-c("patient","glucose_time", "glucose_val","trimester","HBA1c")
mdata_glu1

tmp2
###FIRST_TRIMESTER_HBA1C vs GLU_timepoints####
ggplot(data = mdata_glu1, mapping = aes(x = HBA1c, y = glucose_val)) +
#  geom_violin(mapping = aes(x = variable.y, y = value.x), alpha=1/4)+
  geom_jitter(width = 0.1, height = 0.1,mapping = aes(color=glucose_time, fill=NULL)) +
  ylab(label = "glucose levels") +
  xlab(label = "First trimester HBA1c") +
  geom_smooth(mapping = aes(color=glucose_time),method = glm,se = TRUE, show.legend = F) +
  facet_wrap( nrow = 1, ncol = 4,facets = ~ glucose_time) +
  theme(axis.text.x = element_text(angle = 90)) +
  ggtitle(label = "Newborn Glucose timepoint levels vs First Trimester HBA1c") +
  theme_minimal()

################CORELATION____ANALYSIS############

mdata_glu<-filter(mdata_glu1,!is.na(glucose_val))
a<-glm(formula =  HBA1c ~ glucose_time * glucose_val, data = mdata_glu)
mdata3<-as.tibble(mdata3)
arrange(mdata_glu1,glucose_time)
gluc<-data.frame(mdata_glu1)
glu1<-as.vector(filter(gluc,glucose_time==("Glu1")))
glu1$glu1<-glu1$glucose_val
glu1$glucose_time<-NULL
glu1$glucose_val<-NULL
glu2<-filter(gluc,glucose_time==("Glu2"))
glu3<-filter(gluc,glucose_time==("Glu3"))
glu4<-filter(gluc,glucose_time==("Glu4"))
glu1$glu2<-glu2$glucose_val
glu1$glu3<-glu3$glucose_val
glu1$glu4<-glu4$glucose_val
class(glu1)
# mean(~ mdata$variable * mdata$value)
mdata_glu1
dim(glu1)
library(mosaic)
capture.output(cor.test(HBA1c ~ glu1, data = glu1,method="pearson"),file = "1stTrPearsons_correlation.tsv" )
gf_point(HBA1c ~ glu1, data = glu1) %>%
  #gf_smooth(method = "lm",color ="red", se = T) %>%
  gf_lm(size = 2, linetype ="dashed") +
  #gf_smooth(method = "lm",color ="red", se = T) +
  theme_minimal()

favstats( HBA1c ~ glu1 *glu2 *glu3 *glu4, data = glu1)
#Simple linear regression
cesdmodel <- glm(HBA1c ~ glu1 *glu2 *glu3, data = glu1)
anova(cesdmodel)

capture.output(msummary(cesdmodel), file = "anova_glm_1trimHBA1cvcglu1234.tsv")

##--- Missing value treatment:
c<-cor.test(x = glu1$HBA1c, y=glu1$glu1)

#PREDICTIONS
#make a function that will predict the H1BAC based on the glu1 value
lm_fun<-makeFun(cesdmodel)
#try it out with a glu1 value of 35
lm_fun(glu1 = 25,glu2=45, glu3=55)

#Extract useful quantities
msummary(cesdmodel)
anova(cesdmodel)
coef(cesdmodel)
confint(cesdmodel)
rsquared(cesdmodel)
mplot(cesdmodel, level = 0.95, id.n = 10L,)

