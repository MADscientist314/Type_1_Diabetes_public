##########Vagina########
list<-c('Enhydrobacter','Sneathia','Intestinibacter','Atopobium','Megasphaera','Streptococcus','Gemella','Prevotella_6','Anaerococcus')
list2<-c('Sneathia','Megasphaera','Prevotella_6','Anaerococcus','Bacteroides','Actinomyces','Enterococcus')

print(list)
meta(ASV_physeq_core)
Vagina<-subset_samples(ASV_physeq_core, SampleType=="Vagina")
Vagina<-tax_glom(Vagina, taxrank = "Genus", NArm = T)
taxa_names(Vagina)<-get_taxa_unique(physeq = Vagina, taxonomic.rank = "Genus")
taxa_names(Vagina)
Vagina <- transform(Vagina, 'compositional')
select<-prune_taxa(x = Vagina,taxa=list2)
select
select<-psmelt(select)

select$Genus

library(ggpubr)
p <- ggboxplot(data = select, x = "disease", y = "Abundance",facet.by = "Genus",
               color = "disease",add = "jitter", shape = NULL,title = "Vagina relabund")+ 
  scale_y_log10()+
  stat_compare_means(comparisons = my_comparisons, label.y.npc = 0.5, vjust = 2, )
p
p <- ggboxplot(data = select, x = "disease", y = "Abundance",facet.by = "Genus",
               color = "disease",
               add = "jitter", shape = NULL)+  scale_y_log10()+
  stat_compare_means(comparisons = my_comparisons,method = "t.test", label.y = 4)
p
my_comparisons <- list( c("T1D", "Control") )
p + stat_compare_means(aes(label = paste0("p = ", ..p.format..), ))# Add pairwise comparisons p-value



# Two independent groups
#:::::::::::::::::::::::::::::::::::::::::::::::::
p <- ggboxplot(ToothGrowth, x = "supp", y = "len",
               color = "supp", palette = "npg", add = "jitter")

#  Add p-value
p + stat_compare_means()
# Change method
p + stat_compare_means(method = "t.test")

# Paired samples
#:::::::::::::::::::::::::::::::::::::::::::::::::
ggpaired(ToothGrowth, x = "supp", y = "len",
         color = "supp", line.color = "gray", line.size = 0.4,
         palette = "npg")+
  stat_compare_means(paired = TRUE)

# More than two groups
#:::::::::::::::::::::::::::::::::::::::::::::::::
# Pairwise comparisons: Specify the comparisons you want
my_comparisons <- list( c("0.5", "1"), c("1", "2"), c("0.5", "2") )
ggboxplot(ToothGrowth, x = "dose", y = "len",
          color = "dose", palette = "npg")+
  # Add pairwise comparisons p-value
  stat_compare_means(comparisons = my_comparisons, label.y = c(29, 35, 40))+
  stat_compare_means(label.y = 45)     # Add global Anova p-value

# Multiple pairwise test against a reference group
ggboxplot(ToothGrowth, x = "dose", y = "len",
          color = "dose", palette = "npg")+
  stat_compare_means(method = "anova", label.y = 40)+ # Add global p-value
  stat_compare_means(aes(label = ..p.signif..),
                     method = "t.test", ref.group = "0.5")

# Multiple grouping variables
#:::::::::::::::::::::::::::::::::::::::::::::::::
# Box plot facetted by "dose"
p <- ggboxplot(ToothGrowth, x = "supp", y = "len",
               color = "supp", palette = "npg",
               add = "jitter",
               facet.by = "dose", short.panel.labs = FALSE)
# Use only p.format as label. Remove method name.
p + stat_compare_means(aes(label = paste0("p = ", ..p.format..)))

                       