suppressPackageStartupMessages(library(ggpubr))
suppressPackageStartupMessages(library(cowplot))
# Plot
phist <- gghistogram(
  sam2, x = "newborn_weight", 
  add = "mean", rug = TRUE,
  fill = "disease", palette = c("#61D04F","#2297E6")
)
#> Warning: Using `bins = 30` by default. Pick better value with the argument
#> `bins`.

# Density plot
pdensity <- ggdensity(
  sam2, x = "newborn_weight", 
  color= "disease", palette = c("#61D04F","#2297E6"),
  alpha = 0, xlab = 
) +
  theme_half_open(11, rel_small = 1) +
  scale_y_continuous(
    expand = expansion(mult = c(0, 0.05)),
    position = "right"
  )  +
  theme(
    axis.line.x = element_blank(),
    axis.text.x = element_blank(),
    axis.title.x = element_blank(),
    axis.ticks = element_blank(),
    axis.ticks.length = grid::unit(0, "pt")
  )

# Aligning histogram and density plots
aligned_plots <- align_plots(phist, pdensity, align="hv", axis="tblr")
ggdraw(aligned_plots[[1]]) + draw_plot(aligned_plots[[2]])

