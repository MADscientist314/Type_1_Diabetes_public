library(microbiome)
library(ggpubr)
sam<-data.frame(sample_data(ASV_physeq_core))
alpha<-alpha(x = ASV_physeq_core,index = "shannon")
sam$shannon<-alpha$diversity_shannon
ggviolin(sam, x = "disease", y = "shannon", fill = "disease",
         palette =c("#61D04F","#2297E6"),theme_bw()+
         add = "boxplot", add.params = list(fill = "white"))+
  stat_compare_means(comparisons = my_comparisons, label = "p.signif")+ # Add significance levels
  stat_compare_means(label.y = 10) +facet_grid(facets = ~SampleType)                                     # Add global the p-value 




