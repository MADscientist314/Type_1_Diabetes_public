Data analyzed in the STAMP paper:

Parks DH and Beiko RG. (2010). dentifying biologically relevant differences 
between metagenomic communities. Bioinformatics, 26, 715-721.

In particular, results our based on the file 'MartinEBPR_A_phosphatis.spf' which 
indicates the functional profile for genes associated with A. phospatis.

The original paper describing this data is:

Garcia Martin H, et al. (2006). Metagenomic analysis of two enhanced biological 
phosphorus removal (EBPR) sludge communities. Nat Biotechnol, 24, 1263-9.