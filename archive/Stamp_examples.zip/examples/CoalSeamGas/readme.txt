This data is based on the paper:
An D et al. (2013). . Environ. Sci. Technol., 47, 10708-10717.

Further processing was done by Donovan Parks to produce taxonomic profiles for use with STAMP.