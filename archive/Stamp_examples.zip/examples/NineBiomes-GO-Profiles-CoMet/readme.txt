This data was obtained from the CoMet web server:

Lingner T, et al. (2011). CoMet - a web server for comparative functional 
profiling of metagenomes. Nucleic Acides Research, 39 (suppl 2), W518-W523.

http://comet.gobics.de/

These profiles can be converted to a STAMP profile using:
File->Create STAMP profile from...->CoMet profiles