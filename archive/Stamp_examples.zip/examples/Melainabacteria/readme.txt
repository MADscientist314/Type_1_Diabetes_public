This data is based on the papers:
Di Rienzi, S.C. et al. (2013) The human gut and groundwater harbor non-phtosynthetic bacteria nelonging to a new candidate phylum sibling to Cyanobacteria. eLife, 2, e01102.
Soo, R.M. et al. (2014) An expanded genomic representation of the Phylum Cyanobacteria. Genome Biol Evol, 6, 1031-1045.

Further processing was done by Donovan Parks to produce COG profiles for use with STAMP.