Functional annotation of lean and obese mouse gut communities was obtained from IMG/M:
http://img.jgi.doe.gov/cgi-bin/m/main.cgi

This profile can be directly read by STAMP. The metadata file was created by hand.

Addition COG information can be appended to this profile using:
File->Append COG categories to IMG/M profile...