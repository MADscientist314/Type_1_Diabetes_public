This data is based on the paper:
Arumugam M et al. (2011). Enterotypes of the human gut microbiome. Nature, 473, 174-180.

Genus-level classification were obtained from:
http://www.bork.embl.de/Docu/Arumugam_et_al_2011/downloads.html

Further processing was done by Donovan Parks to format the data for input into STAMP.