Functional annotation of cow rumen data sets obtained from MG-RAST:
http://metagenomics.anl.gov/

These profiles can be converted to a STAMP profile using:
File->Create STAMP profile from...->MG-RAST profile