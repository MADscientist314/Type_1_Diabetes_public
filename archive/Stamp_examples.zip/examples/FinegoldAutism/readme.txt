The original paper describing this data is:

Finegold, S.M. et al. (2010). Pyrosequencing study of fecal microflora 
of autistic and control children. Anaerobe, 16, 444-453.