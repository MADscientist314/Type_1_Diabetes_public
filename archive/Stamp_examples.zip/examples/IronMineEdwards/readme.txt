Data analyzed in the STAMP paper:

Parks DH and Beiko RG. (2010). dentifying biologically relevant differences 
between metagenomic communities. Bioinformatics, 26, 715-721.

The original paper describing this data is:

Edwards R, et al. (2006). Using pyrosequencing to shed light on deep mine 
microbial ecology. BMC Genomics, 7, 57.