sam<-sample_data(ASV_physeq_core)

library(dplyr)
library(broom)
library(mosaic)
library(tidyverse)
library(magrittr)
sam<-read.csv("sample_coreJuly15.txt", header = T, sep = "\t", row.names = 1)
categorical<-c('disease',	'Host',	'SampleType',	'Delivery',	'Antibiotics','Antibiotics_2','Antibiotics_2',	'antibiotic_csec_prophylaxis',	'antibiotic_S_agalactiae',	'antibiotic_Premature_rupture ')
sam<-data.frame(sam)

#################################################
#########2 catergorical variables#################

q <-distinct(select(data.frame(sam),c(patient, disease, Delivery, Antibiotics_2,abx_purpose)))
q1 <- q %>% filter(!is.na(q$Delivery))

#Contingency table with margins

tally(disease ~ Delivery+Antibiotics_2,data =q1 , margins = TRUE)
#Percentages by column
tally(disease ~ Delivery+Antibiotics_2,data =q1,format = "percent")
#Mosaic plot 1
my_tbl<-tally(disease ~ Delivery+Antibiotics_2,data =q1)

mosaicplot(my_tbl ,
           main = "Mosaic plot of Type 1 Diabetes Dataset",
           color = T, las = 1, off=2,
           shade = F, 
           na.action = stats::na.omit)

#Mosaic plot 2
my_tbl<-tally(disease ~ abx_purpose,data =q1)

mosaicplot(my_tbl ,
           main = "Mosaic plot of Antibiotic purpose",
           color = T, las = 1, off=20,
           shade = 1:3)

ct <- table(q1$disease, q1$Delivery)
ct
capture.output(fisher.test(ct), file = "fisher_exact_test_diseasexdeliv.tsv")
ct <- table(q1$disease, q1$Antibiotics_2)
ct
capture.output(fisher.test(ct), file = "fisher_exact_test_diseaseXabx.tsv")
ct <- table(q1$Delivery, q1$Antibiotics_2)
ct
capture.output(fisher.test(ct), file = "fisher_exact_test_deliveryXabx.tsv")

my_tbl<-tally(disease ~ Delivery+Antibiotics_2,data =q1)
a<-mantelhaen.test(my_tbl)
a
capture.output(mantelhaen.test(my_tbl),file = "Cochran-Mantel-Haenszel_test_disease_VS_Delivery+Antibiotics_2.tsv")
#According to this test, there is no relationship between disease and Delivery or ABX, controlling for Location, p=.025.

